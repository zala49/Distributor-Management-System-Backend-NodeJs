export enum Table_Name {
    'users_info' = 'users_info',
    'citys' = 'citys',
    'salesmen' = 'salesmen',
    'distributor' = 'distibutor',
    'merchant' = 'merchant',
    'orders' = 'orders',
    'products' = 'products',
    'products_Categorys' = 'products_Categorys',
    'distributor_city'='distributor_city'
};