Generate Migration

`npm run migration:generate app/migrations/{migration file name}`

Up All Migration

`npm run migration:up`

Down All Migration
    