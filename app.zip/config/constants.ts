export const USER_ROLES = {
    ADMIN: 'Admin',
    SALESMEN: 'Salesmen'
};